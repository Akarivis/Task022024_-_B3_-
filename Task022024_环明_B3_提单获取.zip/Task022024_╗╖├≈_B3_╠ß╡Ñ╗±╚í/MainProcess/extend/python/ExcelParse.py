import pandas as pd


def run(excel_path, invoice_number, invoicing_date, billing_company,issuing_company):
    df_total = pd.read_excel(excel_path)
    list_bill_data = []
    for _, row in df_total.iterrows():
        mbl_no = row["提单号"]
        charge_name = row["费用名称"]
        transaction_date = ""
        currency = row["原币币别"]
        amount = row["原币金额"]
        vessel = row["船名"]
        voyage_no = row["航次"]
        container_type = ""
        container_number = ""
        shipping_terms = ""
        remark = ""
        dict_bill_item = {
            "mbl_no": mbl_no,
            "invoice_number": invoice_number,
            "invoicing_date": invoicing_date,
            "charge_name": charge_name,
            "transaction_date": transaction_date,
            "currency": currency,
            "usdTotal": amount if currency == "USD" else 0.0,
            "rmbTotal": amount if currency == "CNY" else 0.0,
            "vessel": vessel,
            "voyage_no": voyage_no,
            "container_type": container_type,
            "container_number": container_number,
            "shipping_terms": shipping_terms,
            "payer": billing_company,
            "issuing_company":issuing_company,
            "remark": remark
        }
        list_bill_data.append(dict_bill_item)
        # break

    return list_bill_data


if __name__ == '__main__':
    excel_path = r"D:\智慧恒通\项目开发\6.0_new\Task022083_中外运_B3_费用与发票获取\MainProcess\res\ssinvoiceDetail.xlsx"
    invoice_number = "25317000000260109760"
    invoicing_date = '2025-02-13'
    billing_company = "智慧恒通(江苏)供应链科技集团有限公司"
    run(excel_path, invoice_number, invoicing_date, billing_company)
