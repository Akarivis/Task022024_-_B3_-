import datetime
import json
import os

import pymssql
import pymysql
import requests
import urllib3


def getConfig(machine_code):
    """
    根据机器码获取配置信息

    该函数通过发送机器码到指定的URL，以JSON格式获取配置信息

    参数:
    machine_code (str): 设备的唯一机器码，用于识别和获取对应的配置信息

    返回:
    dict: 从服务器获取的配置信息字典，如果URL请求失败或响应数据格式不正确，可能返回None
    """
    # 定义请求的URL，这是获取配置信息的接口地址
    url = "https://platform-rpa.myeverok.com/rest/getParam"

    # 构造请求数据，包含机器码信息
    data = {
        "machineCode": machine_code
    }

    # 发送POST请求到指定URL，并附带JSON格式的数据
    response = requests.post(url, json=data)

    # 从响应文本中解析JSON数据，并提取"mapper"字段的值
    config = json.loads(response.text).get("mapper")

    # 返回提取的配置信息
    return config

def get_error_message(error_message_map,error_code,variable_map):
    """
    根据error_code 获取提前配置的错误描述信息
    :param error_code:  错误码
    :param variable_map: 变量名对应的字典   与数据库里配置的错误信息里的变量名一一对应 例如{"BOOKINGREQ_ID":"123","BOOKING_COMPANY":"234","ROUTE_CODE":"999"}
    :return:
    """
    error_info=error_message_map.get(error_code)
    if not error_info:
        return f'警告！未找到该错误码{error_code}'
    message=error_info.get("cn")
    message_en=error_info.get("en")
    db_variable_map=error_info.get("variable_map")
    if (not message):
        return f'警告！未找到该错误码{error_code}的描述信息'
    if not message_en:
        error_message=f'f"""{message}"""'
    else:
        error_message = f'f"""{message}\n\n\n{message_en}"""'
    """变量初始化赋值"""
    for key,value in db_variable_map.items():
        exec(f"global {key}\n{key}=None")
    """变量赋值"""
    for key,value in variable_map.items():
        exec(f"global {key}\n{key}='{value}'")
    error_message=eval(error_message)
    return error_message


class WinxinApi(object):
    def __init__(self, corpid, secret, agentid, touser='', chatid=''):
        self.secret = secret  # 企业微信应用凭证
        self.corpid = corpid  # 企业微信id
        self.agentid = agentid  # 应用Agentid
        self.touser = touser  # 接收消息的userid
        self.chatid = chatid  # 接收消息的群id
        self.http = urllib3.PoolManager()

    def __get_token(self):
        # '''token获取'''
        url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={}&corpsecret={}".format(self.corpid, self.secret)
        r = self.http.request('GET', url)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            return data['access_token']
        else:
            raise ValueError(data)

    def __upload_file(self, file_path, type='file'):
        # '''上传临时文件'''
        if not os.path.exists(file_path):
            raise ValueError("{},文件不存在".format(file_path))
        file_name = file_path.split("\\")[-1]

        token = self.__get_token()
        with open(file_path, 'rb') as f:
            file_content = f.read()

        files = {'filefield': (file_name, file_content, 'text/plain')}
        # return files
        url = "https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token={}&type={}".format(token, type)
        r = self.http.request('POST', url, fields=files)
        req = r.data.decode("utf-8")
        # req = r.data.decode("utf-8")
        data = json.loads(req)
        # print(data)
        if data["errcode"] == 0:
            return data['media_id']
        else:
            raise ValueError(data)

    def send_file_message(self, file_path):
        token = self.__get_token()

        media_id = self.__upload_file(file_path)
        # return media_id
        # print(media_id)
        body = {
            "agentid": self.agentid,  # agentid
            "touser": self.touser,
            "chatid": self.chatid,
            "msgtype": "file",  # 消息类型，此时固定为：file
            "file": {"media_id": media_id},  # 文件id，可以调用上传临时素材接口获取
            "safe": 0  # 表示是否是保密消息，0表示否，1表示是
        }
        if self.chatid == "":
            url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}".format(token)
        else:
            url = "https://qyapi.weixin.qq.com/cgi-bin/appchat/send?access_token={}".format(token)
        bodyjson = json.dumps(body)
        r = self.http.request('POST', url, body=bodyjson)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            # print("发送文件到企业微信成功")
            return data
        else:
            raise ValueError(data)

def send_message(config, message, touser):
    corpid = config["corpid_me"]
    secret = config["corpsecret_me"]
    agentid = config["agentId_me"]
    url1 = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=" + corpid + "&corpsecret=" + secret
    res = requests.get(url=url1)
    # print(res.text)
    access_token = json.loads(res.text)['access_token']
    url2 = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=" + access_token
    message_js = {
        "touser": touser,
        "msgtype": "text",
        "agentid": agentid,
        "text": {"content": message},
        "safe": 0,
        "enable_id_trans": 0,
        "enable_duplicate_check": 0,
        "duplicate_check_interval": 1800
    }
    res = requests.post(url=url2, json=message_js)



def run(config,platform,company_code,task_mode,bill_no,submit,machine_code):
    # try:
    # 查询当前账号关联的财务同事企业微信账号：
    """暂时没有配置表后续不上"""
    wechat_touser = "nkgjayw"

    if submit == 1:
        connect_name = "connectInfoRPA"
    else:
        connect_name = "connectInfoRPA_test"
    dict_rpa_url = json.loads(config[connect_name])
    with pymysql.connect(host=dict_rpa_url['host'], port=int(dict_rpa_url['port']), user=dict_rpa_url['user'],
                         password=dict_rpa_url['password'], database=dict_rpa_url['database'],
                         charset=dict_rpa_url["charset"]) as mydb:
        with mydb.cursor() as cursor:
            # "获取动态报错信息配置"
            sql = f"select * from T00_SYS_00_B_ERROR_MESSAGE_MAP where carrier='{platform}' and b_type='B3'"
            cursor.execute(sql)
            res = cursor.fetchall()
            error_message_map = {item[2]: {"cn": item[5], "en": item[6],"variable_map": json.loads(item[7])} for item in res}

            # 查看当前机器的信息
            sql = "select * from T00_SYS_00_MACHINE_NAME where MACHINE_CODE = %s"
            cursor.execute(sql,[machine_code])
            result = cursor.fetchone()
            local_ip = result[2]
            machine_name = result[3]

            # 查看账号密码配置信息
            sql = f"select USER_NAME,PASS_WORD from T02_BUSI_0780101_USER_LIST where ACCOUNT_TYPE = 'B3{platform}'"
            cursor.execute(sql)
            list_password_mapping = cursor.fetchall()
            dict_password_mapping = {row[0]:row[1] for row in list_password_mapping}

            # 查看当前需要处理的账号的信息
            company_code=company_code.strip()
            if company_code:
                sql = f"select * from T02_BUSI_02208301_USER_COF where PLATFORM = '{platform}' and COMPANY_CODE = '{company_code}'"
            else:
                sql = f"select * from T02_BUSI_02208301_USER_COF where PLATFORM = '{platform}'"
            cursor.execute(sql)
            list_account = cursor.fetchall()
            if not list_account:
                variable_map = {
                    "PLATFORM":platform,
                    "COMPANY_CODE":company_code
                }
                error_message = get_error_message(error_message_map, 'ERR_CODE_300000', variable_map)
                send_message(config, error_message, wechat_touser)
                raise Exception(error_message)
            login_info = []
            for row in list_account:
                username = row[1]
                password = dict_password_mapping.get(row[1])
                url = row[3]
                company_name = row[4]
                company_code = row[5]
                date_interval = row[8]
                handle_time = row[7]
                new_date = (handle_time + datetime.timedelta(days=int(date_interval))).date()
                invoice_check_flag = row[9]
                invoice_billing_company_conf = row[11]
                invoice_issuing_company_conf = row[10]

                # 如果需要检查发票的开票和抬头公司
                if invoice_check_flag:
                    """发票抬头没有映射关系的直接过滤"""
                    envir_map = {
                        1: "produce",
                        0: "prepare",
                        2: "test",
                    }

                    dict_rpa_url_mye = config.get(f'mye_database_{envir_map.get(submit)}')
                    if invoice_billing_company_conf:
                        with pymssql.connect(host=dict_rpa_url_mye['host'], port=int(dict_rpa_url_mye['port']),
                                             user=dict_rpa_url['user'],
                                             password=dict_rpa_url['password'], database=dict_rpa_url['database'],
                                             as_dict=True) as myRPADB:
                            cursor = myRPADB.cursor()
                            sql = f"""SELECT
                                      tb_ru_sys_param.param_key,
                                      tb_ru_sys_param.param_value,
                                      tb_ru_sys_param.param_value_en,
                                      tb_ru_sys_param.type,
                                      tb_ru_sys_param.id,
                                      tb_ru_sys_param.note
                                    FROM
                                      tb_ru_sys_param with(nolock)
                                        INNER JOIN tb_ru_sys_param_group with(nolock) ON tb_ru_sys_param.group_id= tb_ru_sys_param_group.id
                                    WHERE
                                      tb_ru_sys_param_group.group_id = '{invoice_billing_company_conf}'
                                      AND tb_ru_sys_param.status= 'ENABLE'
                                      AND tb_ru_sys_param_group.status= 'ENABLE'"""
                            cursor.execute(sql)
                            com_config_res = cursor.fetchall()
                    else:
                        com_config_res = ()

                    if invoice_issuing_company_conf:
                            """客户"""
                            sql = f"""SELECT
                                      tb_ru_sys_param.param_key,
                                      tb_ru_sys_param.param_value,
                                      tb_ru_sys_param.param_value_en,
                                      tb_ru_sys_param.type,
                                      tb_ru_sys_param.id,
                                      tb_ru_sys_param.note
                                    FROM
                                      tb_ru_sys_param with(nolock)
                                        INNER JOIN tb_ru_sys_param_group with(nolock) ON tb_ru_sys_param.group_id= tb_ru_sys_param_group.id
                                    WHERE
                                      tb_ru_sys_param_group.group_id = '{invoice_issuing_company_conf}'
                                      AND tb_ru_sys_param.status= 'ENABLE'
                                      AND tb_ru_sys_param_group.status= 'ENABLE'"""
                            cursor.execute(sql)
                            customer_config_res = cursor.fetchall()
                            customer_config_res = list(customer_config_res)
                    else:
                        customer_config_res = ()


                    bill_com_config_list = [item[1] for item in com_config_res]
                    issuing_com_config_list = [item[1] for item in customer_config_res]
                else:
                    bill_com_config_list = issuing_com_config_list = []


                #查询最新的对账和开票日期
                sql = f"select max(INVOICING_DATE) from T02_BUSI_02208304_INVOICE_DATA where company_code = '{company_code}' and platform = '{platform}'"
                cursor.execute(sql)
                result = cursor.fetchone()
                # if cursor.fetchone() is not None:
                #     last_invoicing_date = cursor.fetchone()[0]
                # else:
                last_invoicing_date = result[0]
                if last_invoicing_date:
                    # last_invoicing_date = last_invoicing_date.strptime("%Y-%m-%d")
                    last_invoicing_date = datetime.datetime.strftime(last_invoicing_date, "%Y-%m-%d")

                sql = f"select max(BILLING_DATE) from T02_BUSI_02208305_BILL_DATA where company_code = '{company_code}' and platform = '{platform}'"
                cursor.execute(sql)
                result = cursor.fetchone()
                # if cursor.fetchone() is not None:
                #     last_billing_date = cursor.fetchone()[0]
                # else:
                last_billing_date = result[0]
                if last_billing_date:
                    last_billing_date = datetime.datetime.strftime(last_billing_date,"%Y-%m-%d")
                # if handle_time is None or date_interval is None or new_date<=datetime.date.today():
                login_info.append({
                    "url":url,
                    "username":username,
                    "password":password,
                    "company_name":company_name,
                    "company_code":company_code,
                    "last_billing_date":last_billing_date,
                    "last_invoicing_date":last_invoicing_date
                })

            dict_login_info = {
                "platform": platform,
                "login_info": login_info,   # 账号登录信息
                "task_mode": task_mode,     # 几种业务顺序，发票+账单一起|单发票|单账单
                "bill_no":bill_no.strip().split(";"),          # 当前任务ID
                "invoice_check_flag":invoice_check_flag,
                "invoice_billing_company_list":bill_com_config_list,
                "invoice_issuing_company_list":issuing_com_config_list,
                "submit": submit            # 1:生产 0:预发 2：测试
            }

            list_insert = [json.dumps(dict_login_info),platform,company_code,task_mode,machine_code,machine_name,local_ip]
            sql = "INSERT INTO T02_BUSI_02208302_TASK_RECORD (LOGIN_INFO, PLATFORM, COMPANY_CODE,TASK_MODE, START_TIME, MACHINE_CODE, MACHINE_NAME, LOCAL_IP) VALUES(%s,%s,%s,%s,NOW(),%s,%s,%s);"
            cursor.execute(sql,list_insert)
            current_task_id = cursor.lastrowid
            dict_login_info['current_task_id'] = current_task_id
            mydb.commit()
            cursor.close()
    # except Exception as e:
    #     variable_map = {}
    #     error_message = get_error_message(error_message_map, 'ERR_CODE_300000', variable_map)
    #     send_message(config, error_message, wechat_touser)
    #     raise Exception(error_message)
    return dict_login_info












if __name__ == '__main__':

    platform = "中外运"
    company_code = ""
    task_mode = '1'
    machine_code = "5E15345E7A215F380A36"
    config = getConfig(machine_code)
    bill_no = ""
    submit = 0
    dict_login_info = run(config,platform,company_code,task_mode,bill_no,submit,machine_code)
    print(dict_login_info)

