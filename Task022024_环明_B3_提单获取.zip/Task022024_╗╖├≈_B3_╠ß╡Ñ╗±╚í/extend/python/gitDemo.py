import shutil
import os
import subprocess
import urllib
import pymysql



def get_db_connection(db_config):
    """获取数据库连接"""
    # dict_rpa_url = json.loads(config['connectInfoRPA'])
    mydb = pymysql.connect(host=db_config['host'], port=int(db_config['port']), user=db_config['user'],
                         password=db_config['password'], database=db_config['database'],
                         charset=db_config["charset"])
    return mydb


def get_task_config(task_name, db_config):
    """根据任务名称获取配置信息"""
    connection = get_db_connection(db_config)
    try:
        with connection.cursor() as cursor:
            sql = "SELECT TASK_NAME, PY_NAME, VERSION, GIT_PATH,GIT_USERNAME,GIT_TOKEN FROM T01_BUSI_PY_CONFIG WHERE TASK_NAME = %s"
            cursor.execute(sql, (task_name,))
            result = cursor.fetchall()
            return result
    finally:
        connection.close()
def delete_local_files(repo_path):
    """
    删除指定仓库路径下的所有文件
    :param repo_path: 本地仓库的路径
    """
    for root, dirs, files in os.walk(repo_path, topdown=False):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"删除文件 {file_path} 时出错: {e}")
        for dir in dirs:
            dir_path = os.path.join(root, dir)
            try:
                os.rmdir(dir_path)
            except Exception as e:
                print(f"删除目录 {dir_path} 时出错: {e}")

def copy_single_file(source_file_path, destination_file_path):
    """
    复制单个文件到指定目标路径
    :param source_file_path: 源文件的完整路径
    :param destination_file_path: 目标文件的完整路径
    """
    try:
        # 检查源文件是否存在
        if os.path.isfile(source_file_path):
            # 确保目标文件所在目录存在
            if os.path.exists(destination_file_path):
                os.remove(destination_file_path)

            destination_dir = os.path.dirname(destination_file_path)
            os.makedirs(destination_dir, exist_ok=True)
            # 复制文件
            shutil.copy2(source_file_path, destination_file_path)
            print(f"文件 {source_file_path} 已成功复制到 {destination_file_path}")
        else:
            print(f"源文件 {source_file_path} 不存在。")
    except Exception as e:
        print(f"复制文件时出错: {e}")

def copy_folder(source_folder_path, destination_folder_path):
    """
    复制整个文件夹到指定目标路径
    :param source_folder_path: 源文件夹的完整路径
    :param destination_folder_path: 目标文件夹的完整路径
    """
    try:
        # 检查源文件夹是否存在
        if os.path.isdir(source_folder_path):
            # 复制文件夹
            if os.path.exists(destination_folder_path):
                shutil.rmtree(destination_folder_path)
            shutil.copytree(source_folder_path, destination_folder_path)
            print(f"文件夹 {source_folder_path} 已成功复制到 {destination_folder_path}")
        else:
            print(f"源文件夹 {source_folder_path} 不存在。")
    except Exception as e:
        print(f"复制文件夹时出错: {e}")
def clone_or_pull_repo(git_path, temp_path, username, token, version=None):
    from git import Repo
    # username = '15051812614'
    # password = 'Wj@5991924'

    """克隆或拉取Git仓库"""
    # 创建项目保存目录（如果不存在）
    # temp_path = os.path.join(temp_path,task_name)
    os.makedirs(temp_path, exist_ok=True)

    # 清除 Git 凭证缓存
    git_executable = os.environ['GIT_PYTHON_GIT_EXECUTABLE']
    # 临时禁用凭证助手
    try:
        subprocess.run([git_executable, 'config', '--global', 'credential.helper', ''], check=True)
        print("Git 凭证助手已禁用")
    except subprocess.CalledProcessError as e:
        print(f"禁用 Git 凭证助手时出错: {e}")

    try:
        subprocess.run([git_executable, 'credential-manager-core', 'erase'], check=True)
        print("Git 凭证缓存已清除")
    except subprocess.CalledProcessError as e:
        print(f"清除 Git 凭证缓存时出错: {e}")

    # 构建带有认证信息的 Git 地址
    username_encoded = urllib.parse.quote(username, safe='')
    token_encoded = urllib.parse.quote(token, safe='')
    auth_git_path = git_path.replace("https://", f"https://{username_encoded}:{token_encoded}@")
    full_git_path = auth_git_path.rstrip('/')
    # git_file_path = os.path.join(local_path,'.git')
    try:
        # if os.path.exists(git_file_path):
        #     repo = Repo(temp_path)
        #     # 拉取更新
        #     origin = repo.remotes.origin
        #     origin.fetch()
        #     repo.head.reset(commit=origin.refs.master, working_tree=True)  # 假设默认分支是 master
        #     origin.pull()
        # else:
        # 克隆仓库
        repo = Repo.clone_from(full_git_path, temp_path)

        # version = '3ebe74e087b1789e6e0b553c2e8cefa49b30bf79'

        if version:
            # 切换到指定版本
            repo.git.checkout(version)
        else:
            # 获取默认分支
            default_branch = repo.heads[0].name
            repo.git.checkout(default_branch)

        return temp_path
    except Exception as e:
        print(f"Git操作失败: {str(e)}")
        return None
    finally:
        # 恢复凭证助手（可选）
        try:
            subprocess.run([git_executable, 'config', '--global', 'credential.helper', 'manager-core'], check=True)
            print("Git 凭证助手已恢复")
        except subprocess.CalledProcessError as e:
            print(f"恢复 Git 凭证助手时出错: {e}")

def remove_readonly(func, path, _):
    """清除只读属性并重新尝试删除"""
    os.chmod(path, 0o777)
    func(path)
def manage_task(task_name, local_path, db_config,git_python_git_executable):
    os.environ['GIT_PYTHON_GIT_EXECUTABLE'] = git_python_git_executable
    temp_path = os.path.join(os.path.dirname(local_path),'temp')

    """管理任务"""
    reslut = get_task_config(task_name, db_config)
    if not reslut:
        print(f"Task {task_name} not found in config.")
        return

    for row in reslut:
        if os.path.exists(temp_path):
            shutil.rmtree(temp_path,onerror=remove_readonly)
        # 克隆/拉取代码
        version = row[2]
        git_path = row[3]
        username = row[4]
        token = row[5]
        file_name = row[1]
        repo_dir = clone_or_pull_repo(git_path, temp_path, username, token, version)

        # 从克隆的路径里面找到想要的py
        filepath = os.path.join(temp_path,file_name)
        if not os.path.exists(filepath):
            raise Exception(f"脚本 {file_name} 不存在于 {repo_dir} 中。")

        if os.path.isfile(filepath):
            copy_single_file(filepath, os.path.join(local_path,file_name.split("\\")[-1]))
        elif os.path.isdir(filepath):
            copy_folder(filepath, os.path.join(local_path,file_name.split("\\")[-1]))
        else:
            raise Exception(f"源路径 {file_name} 既不是文件也不是文件夹。")

if __name__ == "__main__":
    # 数据库配置
    DB_CONFIG = {"host":"47.92.113.232","port":13307,"user":"root","password":"EverOK.3307","database":"RPA","charset":"utf8"}

    task_name = "Task_demo"
    local_path = r"C:\Users\JayW\Documents\UiBot\creator\Projects\流程10\extend\python"
    # username = "git"
    # token = "b9ec2e0d09fd471dadf00d3f8cadf943"
    # temp_path = r"C:\Users\JayW\Documents\UiBot\creator\Projects\流程10\res"
    git_python_git_executable = r"D:\Git\bin\git.exe"


    manage_task(task_name,local_path, DB_CONFIG,git_python_git_executable)
