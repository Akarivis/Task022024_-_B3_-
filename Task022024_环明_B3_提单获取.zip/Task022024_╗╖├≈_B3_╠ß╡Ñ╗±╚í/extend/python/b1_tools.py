import datetime
import hashlib
import json
import mimetypes
import os
import time
import pymssql
import requests
import pymysql
import urllib3
from pymysql.cursors import DictCursor
from requests_toolbelt import MultipartEncoder


class WinxinApi(object):
    def __init__(self, corpid, secret, agentid, touser='', totag = '',chatid=''):
        self.secret = secret  # 企业微信应用凭证
        self.corpid = corpid  # 企业微信id
        self.agentid = agentid  # 应用Agentid
        self.touser = touser  # 接收消息的userid
        self.chatid = chatid  # 接收消息的群id
        self.totag = totag    # 接收消息的标签
        self.http = urllib3.PoolManager()

    def __get_token(self):
        # '''token获取'''
        url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={}&corpsecret={}".format(self.corpid, self.secret)
        r = self.http.request('GET', url)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            return data['access_token']
        else:
            raise ValueError(data)

    def __upload_file(self, file_path, type='file'):
        # '''上传临时文件'''
        if not os.path.exists(file_path):
            raise ValueError("{},文件不存在".format(file_path))
        file_name = file_path.split("\\")[-1]

        token = self.__get_token()
        with open(file_path, 'rb') as f:
            file_content = f.read()

        files = {'filefield': (file_name, file_content, 'text/plain')}
        # return files
        url = "https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token={}&type={}".format(token, type)
        r = self.http.request('POST', url, fields=files)
        req = r.data.decode("utf-8")
        # req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            return data['media_id']
        else:
            raise ValueError(data)

    def send_file_message(self, file_path):
        token = self.__get_token()

        media_id = self.__upload_file(file_path)
        # return media_id
        body = {
            "agentid": self.agentid,  # agentid
            "touser": self.touser,
            "totag":self.totag,
            "chatid": self.chatid,
            "msgtype": "file",  # 消息类型，此时固定为：file
            "file": {"media_id": media_id},  # 文件id，可以调用上传临时素材接口获取
            "safe": 0  # 表示是否是保密消息，0表示否，1表示是
        }
        list_urls = []
        if self.totag or self.touser:
            url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}".format(token)
            list_urls.append(url)
        if self.chatid:
            url = "https://qyapi.weixin.qq.com/cgi-bin/appchat/send?access_token={}".format(token)
            list_urls.append(url)
        bodyjson = json.dumps(body)
        for url in list_urls:
            r = self.http.request('POST', url, body=bodyjson)
            req = r.data.decode("utf-8")
            data = json.loads(req)
            if data["errcode"] == 0:
                print("发送文件到企业微信成功")
                # return data
                continue
            else:
                raise ValueError(data)
    def send_img_message(self, file_path):
        token = self.__get_token()

        media_id = self.__upload_file(file_path,"image")
        # return media_id
        body = {
            "agentid": self.agentid,  # agentid
            "touser": self.touser,
            "totag":self.totag,
            "chatid": self.chatid,
            "msgtype": "image",  # 消息类型，此时固定为：file
            "image": {"media_id": media_id},  # 文件id，可以调用上传临时素材接口获取
            "safe": 0  # 表示是否是保密消息，0表示否，1表示是
        }
        list_urls = []
        if self.totag or self.touser:
            url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}".format(token)
            list_urls.append(url)
        if self.chatid:
            url = "https://qyapi.weixin.qq.com/cgi-bin/appchat/send?access_token={}".format(token)
            list_urls.append(url)
        bodyjson = json.dumps(body)
        for url in list_urls:
            r = self.http.request('POST', url, body=bodyjson)
            req = r.data.decode("utf-8")
            data = json.loads(req)
            if data["errcode"] == 0:
                print("发送文件到企业微信成功")
                # return data
                continue
            else:
                raise ValueError(data)

    def send_message(self, toUser, toTag, error_level, error_code, error_desc, task_id, process_id, busi_record_id,
                     exe_machine):
        """
        :param toUser: 错误通知人 多个则用|分割    A|B|C
        :param toTag: 错误通知标签
        :param error_level: 错误危机程度 1: 紧急    2: 重要    3: 普通
        :param error_code: 错误码
        :param error_desc: 错误描述
        :param task_id: 流程ID
        :param process_id: 任务ID
        :param busi_record_id: 业务任务ID
        :param exe_machine: 执行机器 可传机器码 可传IP
        :param toTag: 错误通知标签
        :param toGroup: 错误通知群ID
        :return:
        """
        token = self.__get_token()
        url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}".format(token)
        color = 'black'
        if error_level == '紧急':
            color = 'warning'
        elif error_level == '重要':
            color = 'comment'
        markdown = {
            "content": f"报错通知 \n>   <font color='{color}'>**{error_level}**</font> \n>  <font color='{color}'>流程ID:  {task_id}</font> \n>  <font color='{color}'>任务ID:  {process_id}</font> \n> <font color='{color}'>业务任务ID:  {busi_record_id}</font> \n> <font color='{color}'>错误编码:  {error_code}</font> \n> <font color='{color}'>错误描述:  {error_desc}</font>\n>  <font color='{color}'>机器:  {exe_machine}</font>"
        }

        body = {
            "agentid": self.agentid,  # agentid
            "touser": toUser,
            "totag": toTag,
            "toparty": "",
            "msgtype": "markdown",
            "markdown": markdown,  # 消息类型，此时固定为：file
            "safe": 0,  # 表示是否是保密消息，0表示否，1表示是
            "enable_id_trans": 0,
            "enable_duplicate_check": 0,
            "duplicate_check_interval": 1800
        }
        bodyjson = json.dumps(body)
        r = self.http.request('POST', url, body=bodyjson)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            print("发送消息到企业微信成功")
            return 'success'
        else:
            print(req)
            return 'error'

    def send_message_common(self, message):
        """
        :param toUser: 错误通知人 多个则用|分割    A|B|C
        :param toTag: 错误通知标签
        :param message: 发送的消息内容
        :return:
        """
        token = self.__get_token()
        url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}".format(token)
        body = {
            "agentid": self.agentid,  # agentid
            "touser": self.touser,
            "totag": self.totag,
            "toparty": "",
            "msgtype": "text",
            "text":{
                "content":message
            },
            "safe": 0,  # 表示是否是保密消息，0表示否，1表示是
            "enable_id_trans": 0,
            "enable_duplicate_check": 0,
            "duplicate_check_interval": 1800
        }
        bodyjson = json.dumps(body)
        r = self.http.request('POST', url, body=bodyjson)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            print("发送消息到企业微信成功")
            return 'success'
        else:
            print(req)
            return 'error'

    def send_message_group(self, group_id, error_level, error_code, error_desc, task_id, process_id, busi_record_id,
                           exe_machine):
        """
        :param group_id: 错误通知群ID
        :param error_level: 错误危机程度 1: 紧急    2: 重要    3: 普通
        :param error_code: 错误码
        :param error_desc: 错误描述
        :param task_id: 流程ID
        :param process_id: 任务ID
        :param busi_record_id: 业务任务ID
        :param exe_machine: 执行机器 可传机器码 可传IP

        :return:
        """
        token = self.__get_token()
        url = 'https://qyapi.weixin.qq.com/cgi-bin/appchat/send?access_token={}'.format(token)
        color = 'black'
        if error_level == '紧急':
            color = 'warning'
        elif error_level == '重要':
            color = 'comment'

        markdown = {
            "content": f"报错通知 \n>   <font color='{color}'>**{error_level}**</font> \n>  <font color='{color}'>流程ID:  {task_id}</font> \n>  <font color='{color}'>任务ID:  {process_id}</font> \n> <font color='{color}'>业务任务ID:  {busi_record_id}</font> \n> <font color='{color}'>错误编码:  {error_code}</font> \n> <font color='{color}'>错误描述:  {error_desc}</font>\n>  <font color='{color}'>机器:  {exe_machine}</font>"
        }
        body = {
            "chatid": group_id,
            "msgtype": "markdown",
            "markdown": markdown,  # 消息类型，此时固定为：file
            "safe": 0,  # 表示是否是保密消息，0表示否，1表示是
        }
        bodyjson = json.dumps(body)
        r = self.http.request('POST', url, body=bodyjson)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            print("发送消息到企业微信成功")
            return 'success'
        else:
            print(req)
            return 'error'

    def send_message_group_common(self,message):
        token = self.__get_token()
        url = 'https://qyapi.weixin.qq.com/cgi-bin/appchat/send?access_token={}'.format(token)
        body = {
            "chatid": self.chatid,
            "msgtype": "text",
            "text" : {
                   "content" : message
               },
            "safe": 0,  # 表示是否是保密消息，0表示否，1表示是
        }
        bodyjson = json.dumps(body)
        r = self.http.request('POST', url, body=bodyjson)
        req = r.data.decode("utf-8")
        data = json.loads(req)
        if data["errcode"] == 0:
            print("发送消息到企业微信成功")
            return 'success'
        else:
            print(req)
            return 'error'

class MySQLDataBase:

    def __init__(self,host=None,port=None,username=None,password=None,database=None):

        #cursorclass=cursors.DictCursor
        self.host=host
        self.port=port
        self.username=username
        self.password=password
        self.database=database

    def __enter__(self):
        self.db = pymysql.connect(host=self.host,port=self.port,user=self.username,password=self.password,database=self.database,cursorclass =DictCursor)
        return self.db
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.db:
            self.db.close()

class SQLSERVERDataBase:
    def __init__(self,host=None,port=None,username=None,password=None,database=None):
        #cursorclass=cursors.DictCursor
        self.host=host
        self.port=port
        self.username=username
        self.password=password
        self.database=database

    def __enter__(self):
        self.db = pymssql.connect(host=self.host,port=self.port,user=self.username,password=self.password,database=self.database)
        return self.db
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.db:
            self.db.close()




def send_message(wechat_touser,message):
    param_map=get_param_map()
    corpid_me = param_map.get("corpid_me")  # 企业微信配置信息
    corpsecret_me = param_map.get("corpsecret_me")  # 企业微信配置信息
    agentId_me = param_map.get("agentId_me")  # 企业微信配置信息
    wechat_admin_user = param_map.get("b_receiver")  # nkgjessonh|nkgjayw|nkgforresty
    wechat_touser=f"{wechat_admin_user}|{wechat_touser}"
    wechat = WinxinApi(corpid_me,corpsecret_me,agentId_me, wechat_touser)
    wechat.send_message_common(message)








def upload_bill_file(submit,mbl_no,file_path):
    rpa_db_name_map = {
        1: "rpa_database_produce",
        0: "rpa_database_test",
        2: "rpa_database_test",
        3: "rpa_database_test",
    }
    mye_db_name_map = {
        1: "mye_database_produce",
        0: "mye_database_prepare",
        2: "mye_database_test",
        3: "mye_database_test",
    }
    fms_mye_db_name_map={
        1: 'fms_database_produce',
        0: "fms_database_prepare",
        2: "fms_database_test",
        3: "fms_database_test",
    }
    prefix_url_map={
        1:"https://myeverok.com",
        0:"https://staging.myeverok.com",
        2:"https://test.myeverok.com",
    }
    param_map = get_param_map()
    prefix_url=prefix_url_map.get(submit)
    upload_url = f"{prefix_url}/file/upload"
    get_file_info_by_billid = f"{prefix_url}/file/class/getFileInfo?billId="
    delete_file = f"{prefix_url}/file/deleteFile"
    loginUrl = f"{prefix_url}/everok/b/auth_syslogin.do"
    saveFileDuty = f"{prefix_url}/file/category/saveFileDuty"
    mye_user = param_map.get("02203MyeUserInfo").split("|")[0]
    mye_psd = param_map.get("02203MyeUserInfo").split("|")[1]
    session = None
    result_message="success"
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'}
    db_config_json = param_map.get("db_config_json")
    db_config = json.loads(db_config_json)
    rap_db_config = db_config.get(rpa_db_name_map.get(submit))
    fms_mye_db_config=  db_config.get(fms_mye_db_name_map.get(submit))
    mye_db_config=  db_config.get(mye_db_name_map.get(submit))

    rpa_db_post = rap_db_config.get("host")
    rpa_db_username = rap_db_config.get("username")
    rpa_db_password = rap_db_config.get("password")
    rpa_db_port = int(rap_db_config.get("port"))
    rpa_db_database = rap_db_config.get("database")

    fms_mye_db_host = fms_mye_db_config.get("host")
    fms_mye_db_username = fms_mye_db_config.get("username")
    fms_mye_db_password = fms_mye_db_config.get("password")
    fms_mye_db_port = int(fms_mye_db_config.get("port"))
    fms_mye_db_database = fms_mye_db_config.get("database")

    mye_db_host = mye_db_config.get("host")
    mye_db_username = mye_db_config.get("username")
    mye_db_password = mye_db_config.get("password")
    mye_db_port = int(mye_db_config.get("port"))
    mye_db_database = mye_db_config.get("database")

    with MySQLDataBase(fms_mye_db_host, fms_mye_db_port, fms_mye_db_username, fms_mye_db_password,fms_mye_db_database) as myRPADB:
        cursor = myRPADB.cursor()

        """MYE存在发送分单号的问题，COSCO回复的可能是分单号"""
        """bill_id 对应多个分单号   所有的分单号回来的提单pdf都上传到这个bill_id下面"""
        """self.billId 分单号12位   """
        sql = f"""SELECT sdb.billinfo_id AS bill_id from so_billdoc sb left join so_declare_basicinfo sdb on sb.declare_basicinfo_id = sdb.declare_basicinfo_id where sb.mbl_no ='{mbl_no}' and sb.doc_type ='MBL'"""
        cursor.execute(sql)
        res = cursor.fetchone()
        if not res:
            result_message = f"MYE未查询到该提单号信息 {mbl_no}"
            return result_message
        bill_id = res.get("bill_id")

    with SQLSERVERDataBase(mye_db_host, mye_db_port,mye_db_username, mye_db_password, mye_db_database) as myRPADB:
        cursor = myRPADB.cursor()
        # sql = f"select a.bookingreq_id,b.email  from tb_bookingvessel_shippingorder as a left join tb_mf_user as b on a.creator_code =b.user_code left join tb_mf_bill as c on c.mbl_no=a.mbl_no where c.bill_id='{bill_id}'"
        # cursor.execute(sql)
        # res = cursor.fetchone()

        sql = f"select b.NEED_HBL,b.bill_id from tb_mf_bill as a left join tb_mf_bill_extension as b on a.bill_id =b.bill_id  WHERE a.bill_id ='{bill_id}'"
        cursor.execute(sql)
        need_hbl_res = cursor.fetchone()

    if not need_hbl_res:
        result_message=f"MYE未查询到该提单号信息 {mbl_no}"
        return result_message


    NEED_HBL = need_hbl_res[0]
    bill_id =  need_hbl_res[1]
    if NEED_HBL:
        busstype = 5
    else:
        busstype = 39

    data = {
        "user_code": mye_user,
        "user_password": md5(mye_psd + "@" + mye_user),
        "lang": "zh-cn"
    }
    session = requests.session()
    response = session.post(url=loginUrl, json=data, headers=headers, timeout=15)
    result = response.json()
    if result.get("ret") == 'OK' and "登录成功" in result.get("msg"):
        userInfo = result.get("content")
        userId = userInfo.get("user_id")
    else:
        result_message = f"登录MYE失败  用户名{mye_user} 密码 {mye_psd}"
        return result_message


    file_name = file_path.split("\\")[-1]
    content_type = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'
    data = {
        "file": (file_name, open(file_path, "rb"), content_type),
        "userId": userId,
        "pictype": 'filecenter',
        "bill_id": bill_id,
        "busstype": str(busstype),
    }
    Multipartdata = MultipartEncoder(data)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36",
        "Content-Type": Multipartdata.content_type,
    }

    response = session.post(url=upload_url, data=Multipartdata, headers=headers, timeout=30)
    result = response.json()
    if not (result.get("ret") == "OK" and result.get("content").get("url")):
        result_message = f"上传文件信息失败 参数 {data} mbl {mbl_no}"
        return result_message
    file_id = result.get('content').get("imgId")
    file_url = result.get('content').get("url")
    filename = result.get('content').get("fileName")
    upload_time = int(time.mktime(datetime.datetime.now().timetuple())) * 1000 + datetime.datetime.now().microsecond // 1000
    data = {
        "bill_id": bill_id,
        "busstype": busstype,
        "fileUploadRemark": "",
        "file_id": file_id,
        "file_url": file_url,
        "filename": filename,
        "sourcecode": "fileCenter",
        "upload_time": upload_time,
    }
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
    }
    response = session.post(url=saveFileDuty, json=data, headers=headers, timeout=30)
    result = response.json()
    if not (result.get("ret") == "OK" and result.get("msg") == 'ok'):
        result_message = f"上传文件信息失败  地址 {saveFileDuty} mbl {mbl_no}"
        return result_message

    return result_message


def md5(string):
    # 创建一个 md5 hash 对象
    md5_hash = hashlib.md5()
    # 提供一个二进制字符串给 update 方法
    md5_hash.update(string.encode('utf-8'))
    # 获取 16 进制哈希值
    hex_dig = md5_hash.hexdigest()
    return hex_dig







def get_param_map():
    """
    获取数据库信息
    :param submit: 环境   1：生产环境    0：预发环境     2  测试环境
    :return:
    """

    url = "https://platform-rpa.myeverok.com/rest/getParam"
    data = {
        "machineCode": '3448BD7966FED3300A46'
    }
    response = requests.post(url, json=data)
    if response.status_code != 200:
        raise Exception('访问platform-rpa报错')
    if not response.text:
        raise Exception('platform-rpa返回结果为空')
    try:
        result = json.loads(response.text)
    except Exception as e:
        raise Exception(f'platform-rpa返回结果解析失败 {response.text}')
    param_map = result.get("mapper")
    return param_map


if __name__=="__main__":
    #send_message("nkgforestw","测试")
    result_message=upload_bill_file(0,"COSU2409301151","D:\\workspaces\\python_projects\\SomeTools\\订舱全链路\\B3\\COAU7225052080-20240827064842.PDF")
    print(result_message)